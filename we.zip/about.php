<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - About Us</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <a href="index.php">
                    <h2>Weeho</h2>
                </a>
            </div>
            
            <div class="nav-menu">
                <a href="index.php" class="nav-link">Home</a>
                <a href="events.php" class="nav-link">Events</a>
                <a href="about.php" class="nav-link active">About</a>
                <a href="spotlight.php" class="nav-link">Spotlight</a>
                <a href="teamFeedback.php" class="nav-link">Team Feedback</a>
                <a href="contact.php" class="nav-link">Contact</a>
            </div>
            
            <div class="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </nav>

    <!-- Mobile Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>Weeho</h3>
            <button class="close-btn">&times;</button>
        </div>
        <div class="sidebar-menu">
            <a href="index.php" class="sidebar-link">Home</a>
            <a href="events.php" class="sidebar-link">Events</a>
            <a href="about.php" class="sidebar-link active">About</a>
            <a href="spotlight.php" class="sidebar-link">Spotlight</a>
            <a href="teamFeedback.php" class="sidebar-link">Team Feedback</a>
            <a href="contact.php" class="sidebar-link">Contact</a>
        </div>
    </div>

    <!-- Overlay -->
    <div class="overlay"></div>

    <!-- Main Content -->
    <main class="main-content">
        <!-- About Header -->
        <section class="about-header">
            <div class="container">
                <h1 class="about-title">About Weeho</h1>
                <p class="about-subtitle">Celebrating Indian culture through art, music, and community</p>
            </div>
        </section>

        <!-- Mission Section -->
        <section class="mission-section">
            <div class="container">
                <div class="mission-content">
                    <div class="mission-text">
                        <h2>Our Mission</h2>
                        <p>Weeho is dedicated to preserving and promoting the rich cultural heritage of India through various artistic expressions. We believe in bringing communities together to celebrate the diversity and beauty of Indian traditions.</p>
                        <p>Our platform serves as a bridge connecting artists, performers, and cultural enthusiasts across the nation, fostering creativity and cultural exchange.</p>
                    </div>
                    <div class="mission-image">
                        <img src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=400&fit=crop" alt="Cultural Performance">
                    </div>
                </div>
            </div>
        </section>

        <!-- Vision Section -->
        <section class="vision-section">
            <div class="container">
                <div class="vision-content">
                    <div class="vision-image">
                        <img src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=500&h=400&fit=crop" alt="Traditional Music">
                    </div>
                    <div class="vision-text">
                        <h2>Our Vision</h2>
                        <p>To create a vibrant ecosystem where Indian cultural arts thrive and reach new generations. We envision a future where traditional and contemporary forms of expression coexist and inspire each other.</p>
                        <p>Through our events and workshops, we aim to make cultural arts accessible to everyone, regardless of their background or experience level.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Values Section -->
        <section class="values-section">
            <div class="container">
                <h2 class="section-title">Our Values</h2>
                <div class="values-grid">
                    <div class="value-card">
                        <div class="value-icon">🎭</div>
                        <h3>Cultural Preservation</h3>
                        <p>Safeguarding traditional art forms for future generations</p>
                    </div>
                    <div class="value-card">
                        <div class="value-icon">🤝</div>
                        <h3>Community Building</h3>
                        <p>Bringing people together through shared cultural experiences</p>
                    </div>
                    <div class="value-card">
                        <div class="value-icon">🌟</div>
                        <h3>Innovation</h3>
                        <p>Blending tradition with modern approaches to art and expression</p>
                    </div>
                    <div class="value-card">
                        <div class="value-icon">🎨</div>
                        <h3>Creativity</h3>
                        <p>Encouraging artistic expression and creative exploration</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section class="team-section">
            <div class="container">
                <h2 class="section-title">Meet Our Team</h2>
                <div class="team-grid">
                    <div class="team-member">
                        <div class="member-image">
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face" alt="Team Member">
                        </div>
                        <h3>Arjun Sharma</h3>
                        <p class="member-role">Founder & Cultural Director</p>
                        <p class="member-bio">Classical dancer and cultural enthusiast with 15+ years of experience</p>
                    </div>
                    <div class="team-member">
                        <div class="member-image">
                            <img src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&crop=face" alt="Team Member">
                        </div>
                        <h3>Priya Patel</h3>
                        <p class="member-role">Event Coordinator</p>
                        <p class="member-bio">Expert in organizing cultural events and community outreach programs</p>
                    </div>
                    <div class="team-member">
                        <div class="member-image">
                            <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face" alt="Team Member">
                        </div>
                        <h3>Ravi Kumar</h3>
                        <p class="member-role">Music Director</p>
                        <p class="member-bio">Traditional musician specializing in Indian classical and folk music</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Workshops Section -->
        <section class="workshops-section">
            <div class="container">
                <h2 class="section-title">Our Workshops</h2>
                <div class="workshops-grid">
                    <div class="workshop-card">
                        <div class="workshop-image">
                            <img src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=250&fit=crop" alt="Dance Workshop">
                        </div>
                        <div class="workshop-content">
                            <h3>Classical Dance</h3>
                            <p>Learn traditional Indian dance forms including Bharatanatyam, Kathak, and Odissi</p>
                            <ul>
                                <li>Beginner to advanced levels</li>
                                <li>Professional instructors</li>
                                <li>Performance opportunities</li>
                            </ul>
                        </div>
                    </div>
                    <div class="workshop-card">
                        <div class="workshop-image">
                            <img src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=250&fit=crop" alt="Music Workshop">
                        </div>
                        <div class="workshop-content">
                            <h3>Traditional Music</h3>
                            <p>Master classical instruments like sitar, tabla, flute, and vocal techniques</p>
                            <ul>
                                <li>Individual and group sessions</li>
                                <li>Theory and practical training</li>
                                <li>Concert preparation</li>
                            </ul>
                        <h3>Music Appreciation Classes</h3>
                        <p>
                            Discover the beauty of Indian classical music, understand ragas, talas, and learn to 
                            appreciate the nuances of vocal and instrumental performances.
                        </p>
                        <div class="workshop-details">
                            <span class="detail-item">📅 Bi-weekly</span>
                            <span class="detail-item">⏱️ 1.5 Hours</span>
                            <span class="detail-item">👥 Max 25 Participants</span>
                        </div>
                        <button class="workshop-btn">Join Workshop</button>
                    </div>

                    <div class="workshop-card">
                        <div class="workshop-icon">
                            <div class="icon-bg">🎨</div>
                        </div>
                        <h3>Folk Arts & Crafts</h3>
                        <p>
                            Explore traditional folk arts, crafts, and storytelling techniques from different regions 
                            of India. Learn about cultural significance and historical context.
                        </p>
                        <div class="workshop-details">
                            <span class="detail-item">📅 Weekly</span>
                            <span class="detail-item">⏱️ 3 Hours</span>
                            <span class="detail-item">👥 Max 15 Participants</span>
                        </div>
                        <button class="workshop-btn">Join Workshop</button>
                    </div>

                    <div class="workshop-card">
                        <div class="workshop-icon">
                            <div class="icon-bg">🎭</div>
                        </div>
                        <h3>Performance Skills</h3>
                        <p>
                            Develop stage presence, overcome performance anxiety, and learn techniques for engaging 
                            with audiences. Suitable for all types of performers.
                        </p>
                        <div class="workshop-details">
                            <span class="detail-item">📅 Monthly</span>
                            <span class="detail-item">⏱️ 4 Hours</span>
                            <span class="detail-item">👥 Max 12 Participants</span>
                        </div>
                        <button class="workshop-btn">Join Workshop</button>
                    </div>

                    <div class="workshop-card">
                        <div class="workshop-icon">
                            <div class="icon-bg">📚</div>
                        </div>
                        <h3>Cultural History Sessions</h3>
                        <p>
                            Deep dive into the history and evolution of Indian arts, understand the cultural context, 
                            and learn about legendary artists and their contributions.
                        </p>
                        <div class="workshop-details">
                            <span class="detail-item">📅 Fortnightly</span>
                            <span class="detail-item">⏱️ 2 Hours</span>
                            <span class="detail-item">👥 Max 30 Participants</span>
                        </div>
                        <button class="workshop-btn">Join Workshop</button>
                    </div>

                    <div class="workshop-card">
                        <div class="workshop-icon">
                            <div class="icon-bg">🌐</div>
                        </div>
                        <h3>Digital Arts Promotion</h3>
                        <p>
                            Learn how to promote your art online, build your digital presence, and connect with 
                            audiences through social media and digital platforms.
                        </p>
                        <div class="workshop-details">
                            <span class="detail-item">📅 Monthly</span>
                            <span class="detail-item">⏱️ 2.5 Hours</span>
                            <span class="detail-item">👥 Max 20 Participants</span>
                        </div>
                        <button class="workshop-btn">Join Workshop</button>
                    </div>
                </div>

                <!-- Programs CTA -->
                <div class="programs-cta">
                    <h3>Ready to Start Your Cultural Journey?</h3>
                    <p>All our workshops are completely free and open to everyone. Join our community and discover the joy of Indian arts and culture.</p>
                    <div class="cta-buttons">
                        <a href="index.php#contact" class="cta-primary">Register Now</a>
                        <a href="events.php" class="cta-secondary">View Upcoming Events</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats Section -->
        <section class="stats-section">
            <div class="container">
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-icon">👥</div>
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Community Members</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">🎭</div>
                        <div class="stat-number">50+</div>
                        <div class="stat-label">Talented Artists</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">🎪</div>
                        <div class="stat-number">100+</div>
                        <div class="stat-label">Events Organized</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">🏆</div>
                        <div class="stat-number">25+</div>
                        <div class="stat-label">Awards Won</div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Weeho</h3>
                    <p>Celebrating arts and culture across India through meaningful events and connections.</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="spotlight.php">Spotlight</a></li>
                        <li><a href="teamFeedback.php">Team Feedback</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact</h4>
                    <ul class="footer-links">
                        <li><?php echo CONTACT_EMAIL; ?></li>
                        <li><?php echo CONTACT_PHONE; ?></li>
                        <li><?php echo CONTACT_ADDRESS; ?></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Follow Us</h4>
                    <div class="social-links">
                        <a href="<?php echo TWITTER_URL; ?>" class="social-link" target="_blank">Twitter</a>
                        <a href="<?php echo LINKEDIN_URL; ?>" class="social-link" target="_blank">LinkedIn</a>
                        <a href="<?php echo GITHUB_URL; ?>" class="social-link" target="_blank">GitHub</a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo SITE_NAME . ' ' . CURRENT_YEAR; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
