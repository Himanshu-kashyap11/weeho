<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Events</title>
    <link rel="stylesheet" href="main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <a href="index.php">
                    <h2>Weeho</h2>
                </a>
            </div>
            
            <div class="nav-menu">
                <a href="index.php" class="nav-link">Home</a>
                <a href="events.php" class="nav-link active">Events</a>
                <a href="about.php" class="nav-link">About</a>
                <a href="spotlight.php" class="nav-link">Spotlight</a>
                <a href="teamFeedback.php" class="nav-link">Team Feedback</a>
                <a href="contact.php" class="nav-link">Contact</a>
            </div>
            
            <div class="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </nav>

    <!-- Mobile Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>Weeho</h3>
            <button class="close-btn">&times;</button>
        </div>
        <div class="sidebar-menu">
            <a href="index.php" class="sidebar-link">Home</a>
            <a href="about.php" class="sidebar-link">About</a>
            <a href="events.php" class="sidebar-link active">Events</a>
            <a href="spotlight.php" class="sidebar-link">Spotlight</a>
            <a href="teamFeedback.php" class="sidebar-link">Team Feedback</a>
            <a href="contact.php" class="sidebar-link">Contact</a>
        </div>
    </div>

    <!-- Overlay -->
    <div class="overlay"></div>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Events Header -->
        <section class="events-header">
            <div class="container">
                <h1 class="events-title">Cultural Events</h1>
                <p class="events-subtitle">Discover and participate in amazing cultural events across India</p>
            </div>
        </section>

        <!-- Upcoming Events Section -->
        <section class="upcoming-events-section">
            <div class="container">
                <h2 class="section-title">Upcoming Events</h2>
                <div class="events-grid" id="eventsGrid">
                    <?php
                    // Load events from database
                    $events = getAllEvents();
                    
                    // Display all events
                    foreach ($events as $event) {
                        echo '<div class="event-card">';
                        echo '<div class="event-header">';
                        echo '<div class="event-date">';
                        echo '<span class="date-day">' . date('d', strtotime($event['date'])) . '</span>';
                        echo '<span class="date-month">' . date('M', strtotime($event['date'])) . '</span>';
                        echo '</div>';
                        echo '<div class="event-location">📍 ' . htmlspecialchars($event['city']) . '</div>';
                        echo '</div>';
                        echo '<div class="event-content">';
                        echo '<h3 class="event-title">' . htmlspecialchars($event['title']) . '</h3>';
                        echo '<p class="event-performer"> ' . htmlspecialchars($event['performer']) . '</p>';
                        echo '<p class="event-description">' . htmlspecialchars($event['description']) . '</p>';
                        echo '</div>';
                        echo '<div class="event-actions">';
                        echo '<button onclick="openRegistrationModal(\'' . addslashes(htmlspecialchars($event['title'])) . '\', \'' . $event['id'] . '\')" class="btn btn-primary">Register</button>';
                        echo '<button onclick="openFeedbackModal(\'' . addslashes(htmlspecialchars($event['title'])) . '\', \'' . $event['id'] . '\')" class="btn btn-secondary">Give Feedback</button>';
                        echo '</div>';
                        echo '</div>';
                    }
                    
                    if (empty($events)) {
                        echo '<div class="no-events">';
                        echo '<p>No events available at the moment. Check back soon!</p>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
        </section>

        <!-- Upload New Event Section -->
        <section class="upload-event-section">
            <div class="container">
                <h2 class="section-title">Upload New Event</h2>
                <div class="upload-form-container">
                    <form id="uploadEventForm" class="upload-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="eventTitle">Event Title:</label>
                                <input type="text" id="eventTitle" name="title" required>
                            </div>
                            <div class="form-group">
                                <label for="eventDate">Event Date:</label>
                                <input type="date" id="eventDate" name="date" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="eventPerformer">Performer:</label>
                                <input type="text" id="eventPerformer" name="performer" required>
                            </div>
                            <div class="form-group">
                                <label for="eventCity">City:</label>
                                <input type="text" id="eventCity" name="city" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="eventDescription">Description:</label>
                            <textarea id="eventDescription" name="description" rows="4" required></textarea>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Upload Event</button>
                            <button type="reset" class="btn btn-secondary">Clear Form</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <!-- Registration Modal -->
    <div class="modal" id="registrationModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Event Registration</h2>
                <button class="modal-close" onclick="closeModal('registrationModal')">&times;</button>
            </div>
            <div class="modal-body">
                <p id="registrationEventTitle"></p>
                <form id="registrationForm">
                    <input type="hidden" id="regEventId" name="eventId">
                    <div class="form-group">
                        <label>Name:</label>
                        <input type="text" id="regName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" id="regEmail" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Phone:</label>
                        <input type="tel" id="regPhone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label>Role:</label>
                        <select id="regRole" name="role" required>
                            <option value="">Select Role</option>
                            <option value="participant">Participant</option>
                            <option value="audience">Audience</option>
                            <option value="volunteer">Volunteer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>City:</label>
                        <input type="text" id="regCity" name="city" required>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="closeModal('registrationModal')">Cancel</button>
                        <button type="submit">Register</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Feedback Modal -->
    <div class="modal" id="feedbackModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Event Feedback</h2>
                <button class="modal-close" onclick="closeModal('feedbackModal')">&times;</button>
            </div>
            <div class="modal-body">
                <p id="feedbackEventTitle"></p>
                <form id="feedbackForm">
                    <input type="hidden" id="feedbackEventId" name="eventId">
                    <div class="form-group">
                        <label>Name:</label>
                        <input type="text" id="feedbackName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Rating:</label>
                        <select id="feedbackRating" name="rating" required>
                            <option value="">Select Rating</option>
                            <option value="1">1 - Poor</option>
                            <option value="2">2 - Fair</option>
                            <option value="3">3 - Good</option>
                            <option value="4">4 - Very Good</option>
                            <option value="5">5 - Excellent</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Feedback:</label>
                        <textarea id="feedbackMessage" name="feedback" rows="4" required></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="closeModal('feedbackModal')">Cancel</button>
                        <button type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        // Add CSS animations for notifications
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Modal functions
        function openRegistrationModal(eventTitle, eventId) {
            document.getElementById('registrationEventTitle').textContent = `Register for: ${eventTitle}`;
            document.getElementById('regEventId').value = eventId;
            document.getElementById('registrationModal').style.display = 'flex';
        }

        function openFeedbackModal(eventTitle, eventId) {
            document.getElementById('feedbackEventTitle').textContent = `Feedback for: ${eventTitle}`;
            document.getElementById('feedbackEventId').value = eventId;
            document.getElementById('feedbackModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Show message function
        function showMessage(message, type = 'success') {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message-notification ${type}`;
            messageDiv.textContent = message;
            messageDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                max-width: 300px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                background: ${type === 'success' ? '#22c55e' : '#ef4444'};
                animation: slideIn 0.3s ease-out;
            `;
            
            document.body.appendChild(messageDiv);
            
            setTimeout(() => {
                messageDiv.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    if (messageDiv.parentNode) {
                        messageDiv.parentNode.removeChild(messageDiv);
                    }
                }, 300);
            }, 4000);
        }

        // Handle registration form submission
        document.getElementById('registrationForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Registering...';
            submitBtn.disabled = true;
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            try {
                const response = await fetch('register.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showMessage('Registration successful!', 'success');
                    closeModal('registrationModal');
                    this.reset();
                } else {
                    showMessage('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showMessage('Network error. Please try again.', 'error');
            } finally {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        });

        // Handle feedback form submission
        document.getElementById('feedbackForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Submitting...';
            submitBtn.disabled = true;
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            try {
                const response = await fetch('feedback.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showMessage('Feedback submitted successfully!', 'success');
                    closeModal('feedbackModal');
                    this.reset();
                } else {
                    showMessage('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showMessage('Network error. Please try again.', 'error');
            } finally {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        });

        // Handle upload event form submission
        document.getElementById('uploadEventForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Uploading...';
            submitBtn.disabled = true;
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            try {
                const response = await fetch('uploadEvent.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showMessage('Event uploaded successfully!', 'success');
                    this.reset();
                    // Reload events list
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    showMessage('Error: ' + result.message, 'error');
                }
            } catch (error) {
                showMessage('Network error. Please try again.', 'error');
            } finally {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        });
    </script>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>Weeho</h4>
                    <p>Celebrating arts and culture across India through meaningful events and connections.</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo SITE_NAME . ' ' . CURRENT_YEAR; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

</body>
</html>
