<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method');
}

// Get and sanitize input data
$eventId = sanitizeInput($_POST['eventId'] ?? '');
$name = sanitizeInput($_POST['name'] ?? '');
$rating = (int)($_POST['rating'] ?? 0);
$feedbackText = sanitizeInput($_POST['feedback'] ?? '');

// Validate required fields
if (empty($eventId) || empty($name) || empty($feedbackText)) {
    jsonResponse(false, 'All required fields must be filled');
}

// Validate rating
if ($rating < 1 || $rating > 5) {
    jsonResponse(false, 'Rating must be between 1 and 5');
}

// Create new feedback data
$feedbackData = [
    'id' => generateId('feedback_'),
    'event_id' => $eventId,
    'name' => $name,
    'rating' => $rating,
    'feedback' => $feedbackText,
    'status' => 'active'
];

// Save to database
if (createFeedback($feedbackData)) {
    jsonResponse(true, 'Thank you for your feedback!');
} else {
    jsonResponse(false, 'Failed to save feedback. Please try again.');
}
?>
