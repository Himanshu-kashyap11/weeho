<?php
// Database Configuration for Weeho Cultural Events Platform

class Database {
    private $host = 'localhost';
    private $db_name = 'weeho_db';
    private $username = 'root';
    private $password = '';
    private $conn;
    
    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                )
            );
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
            die("Database connection failed. Please check your database configuration.");
        }
        
        return $this->conn;
    }
}

// Global database helper functions
function getDB() {
    static $database = null;
    if ($database === null) {
        $database = new Database();
    }
    return $database->getConnection();
}

function executeQuery($sql, $params = []) {
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return false;
    }
}

function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt ? $stmt->fetchAll() : [];
}

function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt ? $stmt->fetch() : null;
}

function insertData($table, $data) {
    $columns = implode(',', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
    
    $stmt = executeQuery($sql, $data);
    return $stmt ? $stmt->rowCount() > 0 : false;
}

function updateData($table, $data, $where, $whereParams = []) {
    $setParts = [];
    foreach (array_keys($data) as $key) {
        $setParts[] = "{$key} = :{$key}";
    }
    $setClause = implode(', ', $setParts);
    
    $sql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
    $params = array_merge($data, $whereParams);
    
    $stmt = executeQuery($sql, $params);
    return $stmt ? $stmt->rowCount() : false;
}

// Event functions
function getAllEvents() {
    return fetchAll("SELECT * FROM events ORDER BY date ASC");
}

function getEventById($id) {
    return fetchOne("SELECT * FROM events WHERE id = ?", [$id]);
}

function createEvent($data) {
    return insertData('events', $data);
}

// Registration functions
function createRegistration($data) {
    return insertData('registrations', $data);
}

function getRegistrationsByEvent($eventId) {
    return fetchAll("SELECT * FROM registrations WHERE event_id = ? ORDER BY created_at DESC", [$eventId]);
}

// Feedback functions
function createFeedback($data) {
    return insertData('feedback', $data);
}

function getFeedbackByEvent($eventId) {
    return fetchAll("SELECT * FROM feedback WHERE event_id = ? ORDER BY created_at DESC", [$eventId]);
}

// Team feedback functions
function createTeamFeedback($data) {
    return insertData('team_feedback', $data);
}

function getAllTeamFeedback() {
    return fetchAll("SELECT * FROM team_feedback ORDER BY created_at DESC");
}

// Contact functions
function createContactMessage($data) {
    return insertData('contact_messages', $data);
}

function getAllContactMessages() {
    return fetchAll("SELECT * FROM contact_messages ORDER BY created_at DESC");
}

// Memory functions
function getAllMemories() {
    return fetchAll("SELECT * FROM memories WHERE status = 'active' ORDER BY sort_order ASC, created_at DESC");
}

function createMemory($data) {
    return insertData('memories', $data);
}

// Admin functions
function getAdminStats() {
    $stats = [];
    $stats['total_events'] = fetchOne("SELECT COUNT(*) as count FROM events")['count'] ?? 0;
    $stats['total_registrations'] = fetchOne("SELECT COUNT(*) as count FROM registrations")['count'] ?? 0;
    $stats['total_feedback'] = fetchOne("SELECT COUNT(*) as count FROM feedback")['count'] ?? 0;
    $stats['total_team_feedback'] = fetchOne("SELECT COUNT(*) as count FROM team_feedback")['count'] ?? 0;
    $stats['total_contacts'] = fetchOne("SELECT COUNT(*) as count FROM contact_messages")['count'] ?? 0;
    $stats['avg_rating'] = fetchOne("SELECT AVG(rating) as avg FROM feedback")['avg'] ?? 0;
    return $stats;
}

function getRecentActivity($limit = 10) {
    $sql = "
        (SELECT 'registration' as type, name, created_at, 'Event Registration' as description FROM registrations ORDER BY created_at DESC LIMIT ?)
        UNION ALL
        (SELECT 'feedback' as type, name, created_at, CONCAT('Event Feedback (', rating, '/5)') as description FROM feedback ORDER BY created_at DESC LIMIT ?)
        UNION ALL
        (SELECT 'team_feedback' as type, name, created_at, CONCAT('Team Feedback (', rating, '/5)') as description FROM team_feedback ORDER BY created_at DESC LIMIT ?)
        UNION ALL
        (SELECT 'contact' as type, name, created_at, 'Contact Message' as description FROM contact_messages ORDER BY created_at DESC LIMIT ?)
        ORDER BY created_at DESC LIMIT ?
    ";
    return fetchAll($sql, [$limit, $limit, $limit, $limit, $limit]);
}

// Database setup function
function setupDatabase() {
    try {
        $pdo = getDB();
        
        // Create events table
        $pdo->exec("CREATE TABLE IF NOT EXISTS events (
            id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            date DATE NOT NULL,
            performer VARCHAR(255) NOT NULL,
            city VARCHAR(100) NOT NULL,
            description TEXT,
            image_url VARCHAR(500) DEFAULT NULL,
            status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Create registrations table
        $pdo->exec("CREATE TABLE IF NOT EXISTS registrations (
            id VARCHAR(50) PRIMARY KEY,
            event_id VARCHAR(50) NOT NULL,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            role VARCHAR(100) DEFAULT NULL,
            city VARCHAR(100) DEFAULT NULL,
            status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'confirmed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Create feedback table
        $pdo->exec("CREATE TABLE IF NOT EXISTS feedback (
            id VARCHAR(50) PRIMARY KEY,
            event_id VARCHAR(50) NOT NULL,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) DEFAULT NULL,
            rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
            feedback TEXT NOT NULL,
            status ENUM('active', 'hidden') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Create team_feedback table
        $pdo->exec("CREATE TABLE IF NOT EXISTS team_feedback (
            id VARCHAR(50) PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
            message TEXT NOT NULL,
            status ENUM('active', 'hidden') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Create contact_messages table
        $pdo->exec("CREATE TABLE IF NOT EXISTS contact_messages (
            id VARCHAR(50) PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            subject VARCHAR(255) DEFAULT NULL,
            message TEXT NOT NULL,
            status ENUM('new', 'read', 'responded') DEFAULT 'new',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Create memories table
        $pdo->exec("CREATE TABLE IF NOT EXISTS memories (
            id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) DEFAULT NULL,
            image VARCHAR(500) NOT NULL,
            caption TEXT NOT NULL,
            event_id VARCHAR(50) DEFAULT NULL,
            status ENUM('active', 'hidden') DEFAULT 'active',
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        return true;
    } catch (PDOException $e) {
        error_log("Database setup error: " . $e->getMessage());
        return false;
    }
}

// Initialize database on first load
function initializeDatabase() {
    if (!setupDatabase()) {
        return false;
    }
    
    // Check if sample data exists
    $eventCount = fetchOne("SELECT COUNT(*) as count FROM events")['count'] ?? 0;
    
    if ($eventCount == 0) {
        // Insert sample events
        $sampleEvents = [
            [
                'id' => 'evt_001',
                'title' => 'Classical Sitar Concert',
                'date' => '2025-01-15',
                'performer' => 'Pandit Ravi Kumar',
                'city' => 'Mumbai',
                'description' => 'Experience the soul-stirring melodies of classical Indian sitar music with renowned maestro Pandit Ravi Kumar.'
            ],
            [
                'id' => 'evt_002',
                'title' => 'Bharatanatyam Dance Recital',
                'date' => '2025-01-20',
                'performer' => 'Priya Nair',
                'city' => 'Chennai',
                'description' => 'A mesmerizing evening of traditional Bharatanatyam dance showcasing ancient stories through graceful movements.'
            ],
            [
                'id' => 'evt_003',
                'title' => 'Folk Music Festival',
                'date' => '2025-01-25',
                'performer' => 'Rajasthani Folk Ensemble',
                'city' => 'Delhi',
                'description' => 'Celebrate India\'s rich folk heritage with vibrant performances from Rajasthan\'s most talented musicians.'
            ]
        ];
        
        foreach ($sampleEvents as $event) {
            createEvent($event);
        }
        
        // Insert sample memories
        $sampleMemories = [
            [
                'id' => 'mem_001',
                'title' => 'Classical Evening',
                'image' => 'images/memory1.jpg',
                'caption' => 'A magical evening of classical music that touched everyone\'s hearts.',
                'event_id' => 'evt_001',
                'sort_order' => 1
            ],
            [
                'id' => 'mem_002',
                'title' => 'Dance Performance',
                'image' => 'images/memory2.jpg',
                'caption' => 'Graceful Bharatanatyam performance showcasing Indian cultural heritage.',
                'event_id' => 'evt_002',
                'sort_order' => 2
            ]
        ];
        
        foreach ($sampleMemories as $memory) {
            createMemory($memory);
        }
    }
    
    return true;
}
?>
