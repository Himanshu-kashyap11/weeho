<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method');
}

// Get and sanitize input data
$title = sanitizeInput($_POST['title'] ?? '');
$date = sanitizeInput($_POST['date'] ?? '');
$performer = sanitizeInput($_POST['performer'] ?? '');
$city = sanitizeInput($_POST['city'] ?? '');
$description = sanitizeInput($_POST['description'] ?? '');

// Validate required fields
if (empty($title) || empty($date) || empty($performer) || empty($city)) {
    jsonResponse(false, 'All required fields must be filled');
}

// Validate date format
if (!DateTime::createFromFormat('Y-m-d', $date)) {
    jsonResponse(false, 'Invalid date format');
}

// Additional validation
if (strtotime($date) < time()) {
    jsonResponse(false, 'Event date cannot be in the past');
}

// Check for duplicate events
$existing = fetchOne("SELECT id FROM events WHERE title = ? AND date = ? AND city = ?", [$title, $date, $city]);
if ($existing) {
    jsonResponse(false, 'An event with the same title, date, and city already exists');
}

// Create new event data
$eventData = [
    'id' => generateId('evt_'),
    'title' => $title,
    'date' => $date,
    'performer' => $performer,
    'city' => $city,
    'description' => $description,
    'status' => 'upcoming'
];

// Save to database
if (createEvent($eventData)) {
    jsonResponse(true, 'Event uploaded successfully!');
} else {
    jsonResponse(false, 'Failed to upload event. Please try again.');
}
?>
